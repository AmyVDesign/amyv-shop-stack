// Resend client — implementation TBD
